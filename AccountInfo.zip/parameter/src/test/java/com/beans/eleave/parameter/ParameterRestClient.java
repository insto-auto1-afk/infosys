package com.beans.eleave.parameter;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.beans.account.parameter.dto.ParameterDto;

@RunWith(MockitoJUnitRunner.class)
public class ParameterRestClient extends TestCase {
	
	
	
	
	@Test
	static void parameterGetByIdClient() {
		final String uri = "http://localhost:8081/parameter/getbyid/"+"585309209";
		
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);

		System.out.println(result);
	}
	@Test
	static void parameterGetAllClient() {
		final String uri = "http://localhost:8081/parameter/getall";

		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set("Accept", "*/*");
		ParameterDto parameterDto = new ParameterDto();
		HttpEntity<?> httpEntity = new HttpEntity<Object>(parameterDto,
				requestHeaders);

		ResponseEntity<String> result = restTemplate.exchange(uri,
				HttpMethod.GET, httpEntity, String.class);

		System.out.println(result);
	}

	
}
