/**
 * 
 */
package com.beans.account.parameter.service;

import java.util.List;

import com.beans.account.parameter.dto.ParameterAccountDto;
import com.beans.account.parameter.dto.ParameterDto;

/**
 * @author chandra
 *
 */
public interface ParameterService {

	ParameterAccountDto getById(String id) ;

	List<ParameterDto> getAll();

	
}
