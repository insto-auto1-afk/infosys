package com.beans.account.parameter.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.beans.account.parameter.dto.ParameterAccountDto;
import com.beans.account.parameter.dto.ParameterDto;
import com.beans.account.parameter.service.ParameterService;

@RestController
@RequestMapping(value = "/parameter")
public class AccountController {

	@Autowired
	private ParameterService parameterService;

	@RequestMapping(value = "/getall", method = RequestMethod.GET)
	 List<ParameterDto> getAllParameters() {
		return parameterService.getAll();
	}

	@RequestMapping(value = "/getbyid/{AcId}", method = RequestMethod.GET)
	ResponseEntity<ParameterAccountDto> getParameterById(@PathVariable String AcId) {
		try {
			return ResponseEntity.ok().body(parameterService.getById(AcId));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
	}

	
}
