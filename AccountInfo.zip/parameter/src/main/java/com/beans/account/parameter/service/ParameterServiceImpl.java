package com.beans.account.parameter.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.beans.account.parameter.dto.ParameterAccountDto;
import com.beans.account.parameter.dto.ParameterDto;

@Service
public class ParameterServiceImpl implements ParameterService {
	List<ParameterDto> parameterList = new ArrayList<ParameterDto>();
	

	public ParameterAccountDto getById(String id)  {
		Map<String, ParameterAccountDto> map=new HashMap<String, ParameterAccountDto>();
		ParameterAccountDto pDto=new ParameterAccountDto();
		ParameterAccountDto pDto2=new ParameterAccountDto();
		pDto.setAccountName("Savings Account");
		pDto.setCurrency("AUD");
		pDto.setValueDate("08/11/2018");
		pDto.setCreditAmount("84213.52");
		pDto.setDebitOrCredit("Credit");
		
		pDto2.setAccountName("Current Account");
		pDto2.setCurrency("SGD");
		pDto2.setValueDate("09/12/2018");
		pDto2.setCreditAmount("84423.52");
		pDto.setDebitOrCredit("Credit");
		
		map.put("585309209", pDto);
		map.put("585309210", pDto2);
		
		if(map.get(id)!=null){
			return map.get(id);
		}
			
		return map.get(id);
	}

	public List<ParameterDto> getAll() {
		
		ParameterDto pDto=new ParameterDto();
		ParameterDto pDto2=new ParameterDto();
		pDto.setAccountName("chandra");
		pDto.setAccountNumber("585309209");
		pDto.setAccountType("Savings");
		pDto.setCurrency("AUD");
		pDto.setBalanceDate("08/11/2018");
		pDto.setOpenBalance("84213.52");
		
		pDto2.setAccountName("infosys");
		pDto2.setAccountNumber("585309210");
		pDto2.setAccountType("Current");
		pDto2.setCurrency("SGD");
		pDto2.setBalanceDate("09/12/2018");
		pDto2.setOpenBalance("84413.52");
		
		parameterList.add(pDto);
		parameterList.add(pDto2);
		
		return parameterList;
	}

	
}
