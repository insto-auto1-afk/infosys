package com.beans.account.parameter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

/**
 * Created by Chandra 16/12/21016
 *
 */

@SpringBootApplication
@EnableTransactionManagement
public class ParameterApplication 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(ParameterApplication.class, args);
    }
    @Bean
    public RestTemplate geRestTemplate() {
        return new RestTemplate();
    }
}
