package com.beans.eleave.parameter;

import java.text.ParseException;

import junit.framework.TestCase;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.beans.account.parameter.dto.ParameterDto;

public class ParameterRestClient extends TestCase {
	
	

	public static void main(String args[]) throws ParseException {
		try {
			parameterGetByIdClient();
			parameterGetAllClient();
		} catch (Exception e) {
			e.getMessage();
		}

	}

	static void parameterGetByIdClient() {
		final String uri = "http://localhost:8081/parameter/getbyid/"+"585309209";
		
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);

		System.out.println(result);
	}

	static void parameterGetAllClient() {
		final String uri = "http://localhost:8081/parameter/getall";

		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set("Accept", "*/*");
		ParameterDto parameterDto = new ParameterDto();
		HttpEntity<?> httpEntity = new HttpEntity<Object>(parameterDto,
				requestHeaders);

		ResponseEntity<String> result = restTemplate.exchange(uri,
				HttpMethod.GET, httpEntity, String.class);

		System.out.println(result);
	}

	
}
