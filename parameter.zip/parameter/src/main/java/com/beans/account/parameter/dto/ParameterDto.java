/**
 * 
 */
package com.beans.account.parameter.dto;

import java.io.Serializable;

/**
 * @author chandra
 *
 */
public class ParameterDto implements Serializable {

    private static final long serialVersionUID = 1L;
	private String accountNumber;
	private String currency;
	private String balanceDate;
	private String accountName;
	private String accountType;
	private String openBalance;
	
	 public ParameterDto() {
	    }

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getBalanceDate() {
		return balanceDate;
	}

	public void setBalanceDate(String balanceDate) {
		this.balanceDate = balanceDate;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getOpenBalance() {
		return openBalance;
	}

	public void setOpenBalance(String openBalance) {
		this.openBalance = openBalance;
	}

	
	}
